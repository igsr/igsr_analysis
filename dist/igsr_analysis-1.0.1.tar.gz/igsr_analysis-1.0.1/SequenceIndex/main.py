from SequenceIndex import SequenceIndex

s = SequenceIndex(filepath="/Users/ernesto/Google_Drive/data/1000genomes.sequence.index")

s.runs_per_sample("low coverage")