from BamQC.BamQC import BamQC 

__author__ = 'Ernesto Lowy'
