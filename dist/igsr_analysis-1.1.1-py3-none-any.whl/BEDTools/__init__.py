from BEDTools.BEDTools import BEDTools

__author__ = 'Ernesto Lowy'
