from VariantCalling.GATK import GATK
