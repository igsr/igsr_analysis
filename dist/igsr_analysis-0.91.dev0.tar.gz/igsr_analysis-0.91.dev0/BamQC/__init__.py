from BamQC.BamQC import BamQC 
