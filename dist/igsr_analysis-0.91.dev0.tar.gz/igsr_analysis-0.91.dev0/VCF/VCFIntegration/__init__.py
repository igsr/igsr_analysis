from VCF.VCFIntegration.Beagle import Beagle
from VCF.VCFIntegration.Shapeit import Shapeit
from VCF.VCFIntegration.SNPTools import SNPTools
