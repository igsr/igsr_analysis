from BamQC import BamQC
